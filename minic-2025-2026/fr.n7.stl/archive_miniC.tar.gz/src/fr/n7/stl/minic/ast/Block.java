/**
 * 
 */
package fr.n7.stl.minic.ast;

import java.util.List;

import fr.n7.stl.minic.ast.instruction.Instruction;
import fr.n7.stl.minic.ast.instruction.declaration.FunctionDeclaration;
import fr.n7.stl.minic.ast.scope.Declaration;
import fr.n7.stl.minic.ast.scope.HierarchicalScope;
import fr.n7.stl.minic.ast.scope.SymbolTable;
import fr.n7.stl.tam.ast.Fragment;
import fr.n7.stl.tam.ast.Register;
import fr.n7.stl.tam.ast.TAMFactory;

/**
 * Represents a Block node in the Abstract Syntax Tree node for the Bloc language.
 * Declares the various semantics attributes for the node.
 * 
 * A block contains declarations. It is thus a Scope even if a separate SymbolTable is used in
 * the attributed semantics in order to manage declarations.
 * 
 * @author Marc Pantel
 *
 */
public class Block {

	/**
	 * Sequence of instructions contained in a block.
	 */
	protected List<Instruction> instructions;

	/**
	 * Local scope of the block.
	 */
	protected HierarchicalScope<Declaration> localScope;

	/**
	 * Size of memory (in TAM words) allocated for local variables in this block.
	 * Computed during allocateMemory and used in getCode to generate POP.
	 */
	protected int localSize;

	/**
	 * Constructor for a block.
	 */
	public Block(List<Instruction> _instructions) {
		this.instructions = _instructions;
		this.localSize = 0;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		String _local = "";
		for (Instruction _instruction : this.instructions) {
			_local += _instruction;
		}
		return "{\n" + _local + "}\n" ;
	}
	
	/**
	 * Inherited Semantics attribute to collect all the identifiers declaration and check
	 * that the declaration are allowed.
	 * @param _scope Inherited Scope attribute that contains the identifiers defined previously
	 * in the context.
	 * @return Synthesized Semantics attribute that indicates if the identifier declaration are
	 * allowed.
	 */
	public boolean collectAndPartialResolve(HierarchicalScope<Declaration> _scope) {
		this.localScope = new SymbolTable(_scope);
		boolean ok = true;
		for (Instruction instruction : this.instructions) {
			ok &= instruction.collectAndPartialResolve(this.localScope);
		}
		return ok;
	}
	
	/**
	 * Inherited Semantics attribute to collect all the identifiers declaration and check
	 * that the declaration are allowed.
	 * @param _scope Inherited Scope attribute that contains the identifiers defined previously
	 * in the context.
	 * @param _container Inherited Container attribute that allows to link the return instructions
	 * with the function declaration.
	 * @return Synthesized Semantics attribute that indicates if the identifier declaration are
	 * allowed.
	 */
	public boolean collectAndPartialResolve(HierarchicalScope<Declaration> _scope, FunctionDeclaration _container) {
		this.localScope = new SymbolTable(_scope);
		boolean ok = true;
		for (Instruction instruction : this.instructions) {
			ok &= instruction.collectAndPartialResolve(this.localScope, _container);
		}
		return ok;
	}
	
	/**
	 * Inherited Semantics attribute to check that all identifiers have been defined and
	 * associate all identifiers uses with their definitions.
	 * @param _scope Inherited Scope attribute that contains the defined identifiers.
	 * @return Synthesized Semantics attribute that indicates if the identifier used in the
	 * block have been previously defined.
	 */
	public boolean completeResolve(HierarchicalScope<Declaration> _scope) {
		boolean ok = true;
		for (Instruction instruction : this.instructions) {
			ok &= instruction.completeResolve(this.localScope);
		}
		return ok;
	}

	/**
	 * Synthesized Semantics attribute to check that an instruction if well typed.
	 * @return Synthesized True if the instruction is well typed, False if not.
	 */	
	public boolean checkType() {
        boolean ok = true;
        for (Instruction instruction : this.instructions) {
            ok &= instruction.checkType();
        }
        return ok;
		// throw new SemanticsUndefinedException("Semantics checkType is undefined in Block.");
	}

	/**
	 * Inherited Semantics attribute to allocate memory for the variables declared in the instruction.
	 * Synthesized Semantics attribute that compute the size of the allocated memory. 
	 * @param _register Inherited Register associated to the address of the variables.
	 * @param _offset Inherited Current offset for the address of the variables.
	 */	
	public int allocateMemory(Register _register, int _offset) {
		int currentOffset = _offset;
		for (Instruction instruction : this.instructions) {
			currentOffset += instruction.allocateMemory(_register, currentOffset);
		}
		this.localSize = currentOffset - _offset;
		return this.localSize;
	}

	/**
	 * Inherited Semantics attribute to build the nodes of the abstract syntax tree for the generated TAM code.
	 * Synthesized Semantics attribute that provide the generated TAM code.
	 * @param _factory Inherited Factory to build AST nodes for TAM code.
	 * @return Synthesized AST for the generated TAM code.
	 */
	public Fragment getCode(TAMFactory _factory) {
		Fragment _result = _factory.createFragment();
		for (Instruction instruction : this.instructions) {
			_result.append(instruction.getCode(_factory));
		}
		// Clean up local variable stack space at end of block
		if (this.localSize > 0) {
			_result.add(_factory.createPop(0, this.localSize));
		}
		return _result;
	}

	/**
	 * Generates code for this block without the trailing POP cleanup.
	 * Used for function bodies where RETURN handles stack cleanup.
	 * @param _factory Factory to create TAM instructions.
	 * @return Fragment with the body code, no trailing POP.
	 */
	public Fragment getCodeWithoutCleanup(TAMFactory _factory) {
		Fragment _result = _factory.createFragment();
		for (Instruction instruction : this.instructions) {
			_result.append(instruction.getCode(_factory));
		}
		return _result;
	}

}
